package com.mycompany.app;

import java.io.Serializable;
import java.util.ArrayList;

/** Collection class to hold a list of motorbike
 *  based on hostel applications in Java in Two Semesters
 *  @author Andy
 *  @version 21 April 2021
 */

public class PatientList implements Serializable
{
    private final ArrayList<Pet> patientsToTreat;
    public final int MAX;
        
    /** Constructor initialises the empty motorbike list and sets the maximum list size 
     *  @param   maxIn The maximum number of motorbikes in the list
     */
    public PatientList(int maxIn)
    {
        patientsToTreat = new ArrayList<>();
        MAX = maxIn;
    }
	
    /** Adds a new Motorbike to the list
     *  @param  thePatient The Bike to add
     *  @return Returns true if the bike was added successfully and false otherwise
     */
    
    //you should be able to make similar code to delete bike, search for bikes etc
    public String addPatient(Pet thePatient)
    {
        if(!isFull())
        {
            patientsToTreat.add(thePatient);
            return thePatient.animalName;
        }
        else
        {
            return "Animal not added";
        }
    }
        


   /** Reports on whether or not the list is empty
     *  @return Returns true if the list is empty and false otherwise
     */
    public boolean isEmpty()
    {
        return patientsToTreat.isEmpty();
    }
	
    /** Reports on whether or not the list is full
     *  @return Returns true if the list is full and false otherwise
     */	
    public boolean isFull()
    {
        boolean fullChecker;
        if(patientsToTreat.size() <= MAX){
            fullChecker = false;
        }
        
        else{
            fullChecker = true;
        }
        return fullChecker;
        
    }
        
    /** Gets the total number of motorbikes 
     *  @return Returns the total number of motorbikes currently in the list 
     */
//    public int getTotal()
//    {       
//        return patientsToTreat.size();
//    }
      
     /** Reads the bike at the given position in the list
     *  @param      positionIn The position of the bike in the list
     *  @return     Returns the bike at the  position in the list
     *              or null if no bike at that logical position
     */
//    public Pet getPatient(int positionIn)
//    {
//        if (positionIn < 0 || positionIn >= getTotal()) // check for valid position
//        {
//            return null; // no object found at given position
//        }
//        else
//        {
//            // remove one frm logical poition to get ArrayList position
//            return patientsToTreat.get(positionIn);
//        }
//    }
    
     /** Outputs all the bikes in the list
     *  @return     Returns all the bikes and owners in the list in an easy to read format
     */
    
    public String displayPatient()
    {
      String output = "\n";  
      for (int counter = 0; counter < patientsToTreat.size(); counter++) {
          output += "\n" + "Owenr's Details: ";
          output += "\n" + "Owenr Name: " + patientsToTreat.get(counter).givName;
          output += "\n" + "Owner Surname: " + patientsToTreat.get(counter).familyName;
          output += "\n";
          
          output += "\n" + "animals Details: ";
          output += "\n" + "animal Breed: " + patientsToTreat.get(counter).animalBreed;
          output += "\n" + "animal Name: " + patientsToTreat.get(counter).animalName;
          output += "\n" + "animal Colour: " + patientsToTreat.get(counter).animalColour;
          output += "\n" + "animal Gneder: " + patientsToTreat.get(counter).animalGender;
          output += "\n" + "animal age: " + patientsToTreat.get(counter).age;
          output += "\n" + "animal Weight: " + patientsToTreat.get(counter).animalWeight;
          output += "\n" + "animal Issue: " + patientsToTreat.get(counter).animalIssue;
          output += "\n" + "animal Address: " + patientsToTreat.get(counter).animalAddress;
          output += "\n";

      } 
        return output;
    }
}

